package com.example.thamersaadi.miniprojet;

import java.util.Date;

/**
 * Created by thamersaadi on 16/04/2018.
 */

public class Tache {
    public String Id;
    public String idEmploye;
    public String description;
    public boolean valide;
    public Date date;

}
