package com.example.thamersaadi.miniprojet;

import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class IndexEmployee extends AppCompatActivity {

    ListView listViewEmployees;
    DatabaseReference databaseEmmployees;

    List<Employee> employeeList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index_employee);
        databaseEmmployees= FirebaseDatabase.getInstance().getReference("employees");

        listViewEmployees = (ListView)findViewById(R.id.listViewEmployees);

        employeeList=new ArrayList<>();
    }

    @Override
    protected void onStart() {
        super.onStart();

        databaseEmmployees.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                employeeList.clear();
                for (DataSnapshot employeeSnapshot : dataSnapshot.getChildren())
                {
                   // Artist artist = postSnapshot.getValue(Artist.class);
                    try {
                        Employee employee = employeeSnapshot.getValue(Employee.class);
                        employeeList.add(employee);
                    }
                    catch(Exception ex) {
                        System.out.println( "******************************");
                        System.out.println( ex.getMessage());
                    }

                }
                EmployeeList adapter = new EmployeeList(IndexEmployee.this,employeeList);
                listViewEmployees.setAdapter(adapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
